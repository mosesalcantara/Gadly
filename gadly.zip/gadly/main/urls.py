from django.urls import path
from . import views

app_name = 'main'
urlpatterns = [
    path('user/', views.user, name='user'),
    path('paraphrase/', views.paraphrase, name='paraphrase'),
    path('test/', views.test, name='test')
]
