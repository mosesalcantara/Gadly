from django import forms


class TextForm(forms.Form):
    input_text = forms.CharField(label='Enter Your Phrase', max_length=300);


class UserForm(forms.Form):
    first_name= forms.CharField(max_length=100)
    last_name= forms.CharField(max_length=100)
    email= forms.EmailField()
