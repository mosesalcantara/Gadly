class Trial():
    def trial(self, msg):
        return msg
