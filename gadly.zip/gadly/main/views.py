from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect

from .forms import TextForm, UserForm

from .main import Main

# from .trial import Trial
# Create your views here.


def user(request):
    submitbutton= request.POST.get("submit")

    firstname=''
    lastname=''
    emailvalue=''

    form = UserForm(request.POST or None)
    if form.is_valid():
        firstname= form.cleaned_data.get("first_name")
        lastname= form.cleaned_data.get("last_name")
        emailvalue= form.cleaned_data.get("email")


    context= {'form': form, 'firstname': firstname, 'lastname':lastname,
              'submitbutton': submitbutton, 'emailvalue':emailvalue}

    return render(request, 'main/user.html', context)


def paraphrase(request):

    input_text=''
    output_text=''

    form = TextForm(request.POST or None)
    if form.is_valid():
        input_text= form.cleaned_data.get("input_text")
        output_text= form.cleaned_data.get("input_text")

    context= {'form': form, 'input_text': input_text, 'output_text': output_text}

    return render(request, 'main/paraphrase.html', context)


def test(request):
    obj = Main()
    txt = 'the chairman and chairmen along with man, woman, and worman'
    result = obj.main(txt)
    return HttpResponse(result)


# def test(request):
#     obj = Trial()
#     msg = obj.trial('Hello World')
#     return HttpResponse(msg)
